Khang Nguyen
300007277
ITI-1121 A00

The assignment was to get a program to approach a linear function (for Q1) and a plane function (for Q2) by having the program start at 0 and slowly 
incrementing or decrementing it's coefficients for each entrance +b. The program uses the actual output to find the difference between the programs
function and the actual function, with the information it can choose the increment size.