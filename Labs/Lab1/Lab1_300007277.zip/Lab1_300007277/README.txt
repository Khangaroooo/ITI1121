Student name: Khang Nguyen  
Student number: 300007277  
Course code: ITI1121  
Lab section: A-2  
 
This archive contains the 5 files of the lab 1, that is, this file (README.txt),  
the file FizzBuzz.java in the directory Q2, the files Question3.java, 
AverageDemo.java, Question33.java and ReverseSortDemo.java in Q3, 
LabExercise5.java in Q5 and LabExercise6.java in Q6.