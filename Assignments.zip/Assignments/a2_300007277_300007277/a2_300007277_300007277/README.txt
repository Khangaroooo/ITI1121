Khang Nguyen
300007277
ITI-1121 A00

The assignment was to create our own implementation of the game �MineSweeper�, relying on a stack to implement zone clearing. This assignment 
was also to let us practice our Model-View-Controller design pattern, and also for designing an application utilizing event-driven programming.
