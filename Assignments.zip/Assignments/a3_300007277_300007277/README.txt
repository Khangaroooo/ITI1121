Khang Nguyen
300007277
ITI-1121 A00

The assignment was to create our own implementation of a Instant Insanity solver.The point of this assignment was to learn how to implement
a queue-based algorithm, Explain the term deep copy in your own words, Throw exceptions when necessary and how to 
Explain state space search algorithms in our own words.

BONUS SOLUTION
so for the bonus there is 2 actual solutions and 4 rotations of the solution. what i did was that for the first cube i realised if 
you did not input all of the orientations into your solution but just picked once for every face that was facing up, meaning instead
of 24 orientations you would have 6 for each face. from then on the rest was the same as breadthFirstSearch. if you dont rotate the first cube,
the 4 rotated solutions will not appear as the first rotations are not part of the solution. 
