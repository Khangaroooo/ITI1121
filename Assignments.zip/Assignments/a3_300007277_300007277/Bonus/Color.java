/**
*Color is a enum consisting of 4 different colors
*
*
*@author Khang Nguyen
*/
public enum Color{
		 BLUE, GREEN, RED, WHITE
}